open('totalpeople.txt','w').close()
open('dailycount.txt','w').close()