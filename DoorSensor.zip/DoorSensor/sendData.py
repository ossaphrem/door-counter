fname = "totalpeople.txt"
count = 0
with open(fname, 'r') as f:
    for line in f:
        count +=1
        
result = count / 4

f = open("dailycount.txt", "w")
f.write("Total people today was: ")
f.write(str(result))
f.close()