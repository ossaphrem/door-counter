import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

def send_test_mail(body):
    sender_email = "library-door@cravencc.edu"
    receiver_email = "whitew@cravencc.edu"

    msg = MIMEMultipart()
    msg['Subject'] = 'Daily Door Count'
    msg['From'] = sender_email
    msg['To'] = receiver_email

    msgText = MIMEText('<b>%s</b>' % (body), 'html')
    msg.attach(msgText)

    filename = "dailycount.txt"
    msg.attach(MIMEText(open(filename).read()))

    try:
        with smtplib.SMTP('10.69.117.217', 25) as smtpObj:
            smtpObj.ehlo()
            smtpObj.sendmail(sender_email, receiver_email, msg.as_string())
    except Exception as e:
        print(e)

body_values = "Brought to you by the letter A, for Automatic."
send_test_mail(body_values)